/*
 * cryptoComp4.c
 *
 *  Created on: 2019. 6. 27.
 *      Author: HD
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define MSG_SIZE 32
#define BLK_SIZE 32 / 2
#define U_CHAR unsigned char
#define U_INT unsigned int

const U_CHAR S_BOX_TABLE[256] =
	{0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
	0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
	0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
	0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
	0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
	0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
	0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
	0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
	0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
	0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
	0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
	0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
	0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
	0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
	0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
	0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16
	};

void Comp(int j, U_CHAR msg[MSG_SIZE], U_CHAR hash[BLK_SIZE]);	// 압축함수

U_CHAR SBox(U_CHAR x);	// 8비트 입력 8비트 출력

U_CHAR GF_Multiply(U_CHAR x, int i);	// 8비트 유한체 곱

void MAT_Multiply(U_CHAR y[BLK_SIZE / 4], U_CHAR x[BLK_SIZE / 4]);	// 32비트 행렬곱

void F(U_CHAR y[4], U_CHAR rk[BLK_SIZE / 4], U_CHAR x[BLK_SIZE / 4]);

void Round(U_CHAR rk[BLK_SIZE / 4], U_CHAR x[BLK_SIZE]);

void Round_p(U_CHAR rk[BLK_SIZE / 4], U_CHAR x[BLK_SIZE]);

void add(U_CHAR msg[MSG_SIZE]);

int collision_check(U_CHAR H1[BLK_SIZE], U_CHAR H2[BLK_SIZE]);

void msg_print(U_CHAR msg[MSG_SIZE]);

void hash_print(int j, U_CHAR hash[BLK_SIZE]);

void msg_gen(U_CHAR m[MSG_SIZE]);

int main(void)
{
	/*U_CHAR msg[MSG_SIZE] = {
			0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
			0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
			0x0a, 0x1a,	0x2a, 0x3a, 0x4a, 0x5a, 0x6a, 0x7a, 0x8a,
			0x9a, 0xaa,	0xba, 0xca, 0xda, 0xea, 0xfa		// 크기 32의 8비트 단위벡터
	};*/	// original

	U_CHAR msg_original[MSG_SIZE] = {
			0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
			0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
			0x0a, 0x1a,	0x2a, 0x3a, 0x4a, 0x5a, 0x6a, 0x7a, 0x8a,
			0x9a, 0xaa,	0xba, 0xca, 0xda, 0xea, 0xfa
	};
	U_CHAR msg_collision[MSG_SIZE] = {
			0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
			0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0e,
			0x0a, 0x1a,	0x2a, 0x3a, 0x4a, 0x5a, 0x6a, 0x7a, 0x8a,
			0x9a, 0xaa,	0xba, 0xca, 0xda, 0xea, 0xfb
	};

	U_CHAR H1[BLK_SIZE];
	U_CHAR H2[BLK_SIZE];
	int j = 3;
	srand(time(NULL));

	Comp(j, msg_original, H1);
	Comp(j, msg_collision, H2);

	/*for(int i = 0 ; i < 255 ; i++)
	{
		msg_collision[0] = i;
		Comp(j, msg_collision, H2);
		if(H1[0] != H2[0])
			continue;
		else
		{
			printf("i = %02x \n", i);
			break;
		}
	}*/

	for(int i = 0 ; i < MSG_SIZE ; i++)
	{
		if(msg_original[i] != msg_collision[i])
		{
			printf("msg different \n");
			break;
		}
		else
		{
			if(i == MSG_SIZE-1)
				printf("msg match \n");
		}
	}


	printf("msg1: ");
	for(int j = 0 ; j < MSG_SIZE ; j++)
		printf("%02x ", msg_original[j]);
	printf("\nmsg2: ");
	for(int j = 0 ; j < MSG_SIZE ; j++)
		printf("%02x ", msg_collision[j]);

	printf("\n\n");

	for(int i = 0 ; i < BLK_SIZE ; i++)
	{
		if(H1[i] != H2[i])
		{
			printf("hash different \n");
			break;
		}
		else
		{
			if(i == BLK_SIZE-1)
				printf("hash match \n");
		}
	}

	printf("Hash1: ");
	for(int j = 0 ; j < BLK_SIZE ; j++)
		printf("%02x ", H1[j]);
	printf("\nHash2: ");
	for(int j = 0 ; j < BLK_SIZE ; j++)
		printf("%02x ", H2[j]);
	printf("\n");

	printf("done \n");

	return 0;
}

void msg_gen(U_CHAR m[MSG_SIZE])
{
	for(int i = 0 ; i < MSG_SIZE ; i++)
		m[i] = rand() % 255;
}

void Comp(int j, U_CHAR msg[MSG_SIZE], U_CHAR hash[BLK_SIZE])
{
	U_CHAR X0[BLK_SIZE];
	U_CHAR K0[BLK_SIZE];

	U_CHAR X1[BLK_SIZE];
	U_CHAR K1[BLK_SIZE];

	U_CHAR XJ[BLK_SIZE];

	U_CHAR RK[BLK_SIZE / 4];

	for(int i = 0 ; i < BLK_SIZE ; i++)
	{
		X0[i] = msg[i];
		X1[i] = msg[i];
		K0[i] = msg[i + BLK_SIZE];
		K1[i] = msg[i + BLK_SIZE];
	}

	for(int i = 0 ; i < j - 1 ; i++)
	{
		U_CHAR RK_seed[4] = {i, i+1, i+2, i+3};

		RK[0] = K1[0];		// rk(i)  = (Ki[0], Ki[1], Ki[2], Ki[3])
		RK[1] = K1[1];
		RK[2] = K1[2];
		RK[3] = K1[3];

		Round(RK, X1);		// X(i+1) = Round(rk(i), X(i)
		Round(RK_seed, K1);	// K(i+1) = Round((i, i+1, i+2, i+3), K(i))
	}


	for(int i = 0 ; i < BLK_SIZE ; i++)
		XJ[i] = X1[i];

	RK[0] = K1[0];		//rk(j-1) = (K(j-1)[0], K(j-1)[1], K(j-1)[2], K(j-1)[3])
	RK[1] = K1[1];
	RK[2] = K1[2];
	RK[3] = K1[3];

	Round_p(RK, XJ);

	for(int i = 0 ; i < BLK_SIZE ; i++)
		hash[i] = XJ[i] ^ X0[i] ^ K0[i];
}

U_CHAR SBox(U_CHAR x)
{
	U_CHAR y = S_BOX_TABLE[x];

	return y;
}

U_CHAR GF_Multiply(U_CHAR x, int i)
{
	U_CHAR y = x << 1;

	if(x & 0b10000000)		// 2 * x
		y ^= 0b00011011;	// x7 = 0 -> x << 1
							// x7 = 1 -> (x << 1) ^ 00011011
	if(i == 3)				// 3 * x
		y ^= x;				// 2 * x ^ x로 변환, 2 * x는 상단 코드에서 진행

	return y;
}

void MAT_Multiply(U_CHAR y[BLK_SIZE / 4], U_CHAR x[BLK_SIZE / 4])
{
	y[0] = GF_Multiply(x[0], 2)^GF_Multiply(x[1], 3)^x[2]^x[3];
	y[1] = x[0]^GF_Multiply(x[1], 2)^GF_Multiply(x[2], 3)^x[3];
	y[2] = x[0]^x[1]^GF_Multiply(x[2], 2)^GF_Multiply(x[3], 3);
	y[3] = GF_Multiply(x[0], 3)^x[1]^x[2]^GF_Multiply(x[3], 2);
}

void F(U_CHAR y[BLK_SIZE / 4], U_CHAR rk[BLK_SIZE / 4], U_CHAR x[BLK_SIZE / 4])
{
	U_CHAR a[BLK_SIZE / 4];
	U_CHAR b[BLK_SIZE / 4];

	for(int i = 0 ; i < BLK_SIZE / 4 ; i++)
	{
		a[i] = x[i] ^ rk[i];
		b[i] = SBox(a[i]);
	}
	MAT_Multiply(y, b);
}

void Round(U_CHAR rk[BLK_SIZE / 4], U_CHAR x[BLK_SIZE])
{
	U_CHAR x_ori[BLK_SIZE];
	U_CHAR y[4] = {x[0], x[1], x[2], x[3]};

	for(int i = 0 ; i < BLK_SIZE ; i++)
		x_ori[i] = x[i];

	F(y, rk, y);
	x[0] = y[0] ^ x_ori[4];
	x[1] = y[1] ^ x_ori[5];
	x[2] = y[2] ^ x_ori[6];
	x[3] = y[3] ^ x_ori[7];

	x[4] = x_ori[8];
	x[5] = x_ori[9];
	x[6] = x_ori[10];
	x[7] = x_ori[11];

	x[8] = x_ori[12];
	x[9] = x_ori[13];
	x[10] = x_ori[14];
	x[11] = x_ori[15];

	x[12] = x_ori[0];
	x[13] = x_ori[1];
	x[14] = x_ori[2];
	x[15] = x_ori[3];
}

void Round_p(U_CHAR rk[BLK_SIZE / 4], U_CHAR x[BLK_SIZE])
{
	U_CHAR x_ori[BLK_SIZE];
	U_CHAR y[4] = {x[0], x[1], x[2], x[3]};

	for(int i = 0 ; i < BLK_SIZE ; i++)
		x_ori[i] = x[i];

	x[0] = x_ori[0];
	x[1] = x_ori[1];
	x[2] = x_ori[2];
	x[3] = x_ori[3];

	F(y, rk, y);
	x[4] = y[0] ^ x_ori[4];
	x[5] = y[1] ^ x_ori[5];
	x[6] = y[2] ^ x_ori[6];
	x[7] = y[3] ^ x_ori[7];

	x[8] = x_ori[8];
	x[9] = x_ori[9];
	x[10] = x_ori[10];
	x[11] = x_ori[11];

	x[12] = x_ori[12];
	x[13] = x_ori[13];
	x[14] = x_ori[14];
	x[15] = x_ori[15];
}

void add(U_CHAR msg[MSG_SIZE])
{
	U_CHAR carry = 0;
	unsigned int current = msg[31];
	int index = 31;

	current++;
	carry = (current >> 8);
	msg[31] = (U_CHAR) current;

	while(carry)
	{
		index--;
		current = msg[index];
		current += carry;
		carry = (current >> 8);
		msg[index] = (U_CHAR) current;
	}

}

int collision_check(U_CHAR H1[BLK_SIZE], U_CHAR H2[BLK_SIZE])
{
	if(H1[0] == H2[0] && H1[1] == H2[1] && H1[2] == H2[2] && H1[3] == H2[3]
		&& H1[4] == H2[4] && H1[5] == H2[5] && H1[6] == H2[6] && H1[7] == H2[7]
		&& H1[8] == H2[8] && H1[9] == H2[9] && H1[10] == H2[10] && H1[11] == H2[11]
		&& H1[12] == H2[12] && H1[13] == H2[13] && H1[14] == H2[14] && H1[15] == H2[15] )
		return 1;
	else
		return 0;
}

void msg_print(U_CHAR msg[MSG_SIZE])
{
	printf("Message: ");
	for(int i = 0 ; i < MSG_SIZE ; i++)
		printf("%02x ", msg[i]);
	printf("\n");
}

void hash_print(int j, U_CHAR hash[BLK_SIZE])
{
	printf("j = %d: ", j);
	for(int i = 0 ; i < BLK_SIZE ; i++)
		printf("%02x ", hash[i]);
	printf("\n\n");
}
