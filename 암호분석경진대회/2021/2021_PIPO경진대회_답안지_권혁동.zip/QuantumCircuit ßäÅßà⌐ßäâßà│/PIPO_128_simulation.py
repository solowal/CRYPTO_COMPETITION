
from projectq.ops import H, CNOT, Measure, Toffoli, X, All , Swap
from projectq import MainEngine
from projectq.backends import ResourceCounter, ClassicalSimulator
from projectq.meta import Loop, Compute, Uncompute, Control

def PIPO(eng):

    x = eng.allocate_qureg(64)
    k0 = eng.allocate_qureg(64)
    k1 = eng.allocate_qureg(64)

    # Plaintext : 0x098552f6_1e270026
    # Key : 0x6DC416DD_779428D2_7E1D20AD_2E152297
    Round_constant_XOR(eng, x, 0x098552f61e270026, 64) # Set PT
    Round_constant_XOR(eng, k0, 0x7E1D20AD2E152297, 64) # Set Key
    Round_constant_XOR(eng, k1, 0x6DC416DD779428D2, 64)  # Set Key

    # Add whitening key
    for i in range(64):
        CNOT | (k0[i], x[i])

    # Round function (13 rounds),
    # Key generation performed with X gate (Round Constant XOR)

    X | k1[0]
    Round(eng, x, k1) #1
    #X | k1[0]


    X | k0[1]
    Round(eng, x, k0) #2
    X | k0[1]


    #X | k1[0]
    X | k1[1]
    Round(eng, x, k1) #3
    #X | k1[0]
    X | k1[1]

    X | k0[2]
    Round(eng, x, k0) #4
    #X | k0[2]


    #X | k1[0]
    X | k1[2]
    Round(eng, x, k1) #5
    #X | k1[0]
    #X | k1[2]

    X | k0[1]
    #X | k0[2]
    Round(eng, x, k0) #6
    X | k0[1]
    X | k0[2]


    #X | k1[0]
    X | k1[1]
    #X | k1[2]
    Round(eng, x, k1) #7
    #X | k1[0]
    X | k1[1]
    X | k1[2]


    X | k0[3]
    Round(eng, x, k0) #8
    #X | k0[3]


    #X | k1[0]
    X | k1[3]
    Round(eng, x, k1) #9
    #X | k1[0]
    #X | k1[3]


    X | k0[1]
    #X | k0[3]
    Round(eng, x, k0) #10
    X | k0[1]
    #X | k0[3]


    #X | k1[0]
    X | k1[1]
    #X | k1[3]
    Round(eng, x, k1) #11
    #X | k1[0]
    X | k1[1]
    #X | k1[3]


    X | k0[2]
    #X | k0[3]
    Round(eng, x, k0) #12

    #X | k1[0]
    X | k1[2]
    #X | k1[3]
    Round(eng, x, k1) #13


    All(Measure) | x
    print('Ciphertext:')
    for i in range(64):
        print(int(x[63 - i]), end=' ')
    print('\n')

####################################

def Sbox3(eng, x):

    Toffoli | (x[0], x[1], x[2])

    X | x[2]
    X | x[1]
    Toffoli | (x[2], x[1], x[0])
    #X | x[0]
    #X | x[2]  # reverse
    #X | x[1]

    #X | x[2]
    #X | x[0]
    Toffoli | (x[2], x[0], x[1])
    #X | x[1]
              # reverse
    #X | x[2] (reverse omitted)
    X | x[0]

def Sbox5_1(eng, x):

    Toffoli | (x[4], x[3], x[2])
    Toffoli | (x[0], x[2], x[1])
    CNOT | (x[1], x[4])
    CNOT | (x[0], x[3])

    X | x[1]
    X | x[2]
    Toffoli | (x[1], x[2], x[0])
    X | x[0]
    X | x[1]  #reverse
    X | x[2]

    CNOT | (x[4], x[2])
    Toffoli | (x[2], x[3], x[1])

def Sbox5_2(eng, x):

    Toffoli | (x[4], x[2], x[3])
    CNOT | (x[3], x[4])

    CNOT | (x[2], x[0])

    Toffoli | (x[0], x[4], x[1])

    # 3-bit : x0, x1, x4 (XOR to 3-bit)
    # 2-bit : x2, x3     (store)

def Sbox5_2_new(eng, x):

    Toffoli | (x[4], x[2], x[3])

    X | x[1]
    X | x[0]
    Toffoli | (x[1], x[0], x[3])
    #X | x[3]
    #X | x[1]
    X | x[0]

    #X | x[3]
    #X | x[1]
    Toffoli | (x[3], x[1], x[2])
    X | x[2]
    X | x[3]
    X | x[1]

def New_Sbox(eng, x):
    Sbox5_1(eng, x[3:8])
    Sbox3(eng, x[0:3])

    #Extend XOR
    CNOT | (x[1], x[7])
    CNOT | (x[2], x[3])
    CNOT | (x[0], x[4])

    with Compute(eng):
        Sbox5_2(eng, x[3:8]) # t0,1,2 --> x7, 3, 4

    CNOT | (x[7], x[2]) #x[2]^t[0]
    CNOT | (x[4], x[1]) #x[1]^t[2]
    CNOT | (x[3] ,x[0]) #x[0]^t[1]

    Uncompute(eng)
    Sbox5_2_new(eng, x[3:8])

    Swap | (x[7], x[0]) #New x[0](x[7]), x[7] = x[0]^t[1]
    Swap | (x[7], x[1]) #New x[7](x[1]^t[2], x[1] = x[0]^t[1]
    Swap | (x[3], x[6])
    Swap | (x[4], x[5])

def R_layer(eng, x):

    for j in range(1):  # Rotate X[1] right by 1
        for i in range(7):
            Swap | (x[i+8], x[i + 9])

    for j in range(4):  # Rotate X[2] right by 4
        for i in range(7):
            Swap | (x[i+16], x[i + 17])

    for j in range(5):  # Rotate X[3] right by 5
        for i in range(7):
            Swap | (x[i+24], x[i + 25])

    for j in range(2):  # Rotate X[4] right by 2
        for i in range(7):
            Swap | (x[i+32], x[i + 33])

    for j in range(3):  # Rotate X[5] right by 3
        for i in range(7):
            Swap | (x[i+40], x[i + 41])

    for j in range(7):  # Rotate X[6] right by 7
        for i in range(7):
            Swap | (x[i+48], x[i + 49])

    for j in range(6):  # Rotate X[7] right by 6
        for i in range(7):
            Swap | (x[i+56], x[i + 57])

def Round(eng, x, k):

    # Sbox
    S0 = [x[0],x[8],x[16],x[24],x[32],x[40],x[48],x[56]]
    S1 = [x[1], x[9], x[17], x[25], x[33], x[41], x[49], x[57]]
    S2 = [x[2], x[10], x[18], x[26], x[34], x[42], x[50], x[58]]
    S3 = [x[3], x[11], x[19], x[27], x[35], x[43], x[51], x[59]]
    S4 = [x[4], x[12], x[20], x[28], x[36], x[44], x[52], x[60]]
    S5 = [x[5], x[13], x[21], x[29], x[37], x[45], x[53], x[61]]
    S6 = [x[6], x[14], x[22], x[30], x[38], x[46], x[54], x[62]]
    S7 = [x[7], x[15], x[23], x[31], x[39], x[47], x[55], x[63]]

    New_Sbox(eng, S0)
    New_Sbox(eng, S1)
    New_Sbox(eng, S2)
    New_Sbox(eng, S3)
    New_Sbox(eng, S4)
    New_Sbox(eng, S5)
    New_Sbox(eng, S6)
    New_Sbox(eng, S7)

    R_layer(eng, x)

    # AddRoundkey
    for i in range(64):
        CNOT | (k[i], x[i])

def Round_constant_XOR(eng, k, rc, bit):
    for i in range(bit):
        if(rc >> i & 1):
             X | k[i]


simul = ClassicalSimulator()
eng = MainEngine(simul)
(PIPO(eng))

eng.flush()
