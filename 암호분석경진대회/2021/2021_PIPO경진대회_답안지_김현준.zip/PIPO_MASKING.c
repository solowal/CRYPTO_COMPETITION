#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define HARDWARE
#define SOFTWARE

#define DEBUG

#define PIPO64_128
//#define PIPO64_256

#ifdef PIPO64_128
#define ROUND 13
#define SIZE 2                //64 = 32 * 2
#define INT_NUM 2            //64 = 32 * 2
#define MASTER_KEY_SIZE 2    //128 = 64 * 2
#elif defined PIPO64_256
#define ROUND 17
#define SIZE 2
#define INT_NUM 2
#define MASTER_KEY_SIZE 4    //256 = 64 * 2
#endif

#define NUM_SHARES 2

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;

u32 MASTER_KEY[MASTER_KEY_SIZE * INT_NUM] = { 0, };
u32 ROUND_KEY[(ROUND + 1) * INT_NUM] = { 0, };
u32 PLAIN_TEXT[SIZE] = { 0, };
u32 CIPHER_TEXT[SIZE] = { 0, };
u32 CIPHER_TEXT2[SIZE] = { 0, };
u32 CIPHER_TEXT3[SIZE] = { 0, };
void keyadd(u8* val, u8* rk)
{
    val[0] ^= rk[0];
    val[1] ^= rk[1];
    val[2] ^= rk[2];
    val[3] ^= rk[3];
    val[4] ^= rk[4];
    val[5] ^= rk[5];
    val[6] ^= rk[6];
    val[7] ^= rk[7];
}

void sbox(u8 *X)
{
    u8 T[3] = { 0, };
    //(MSB: x[7], LSB: x[0])
    // Input: x[7], x[6], x[5], x[4], x[3], x[2], x[1], x[0]
    //S5_1
   
    
    X[5] ^= (X[7] & X[6]);
    
    X[4] ^= (X[3] & X[5]);
    
    X[7] ^= X[4];
    
    X[6] ^= X[3];
    
    X[3] ^= (X[4] | X[5]);
    
    X[5] ^= X[7];
    
    X[4] ^= (X[5] & X[6]);
    
    //S3
    X[2] ^= X[1] & X[0];
    X[0] ^= X[2] | X[1];
    X[1] ^= X[2] | X[0];
    
    X[2] = ~X[2];
    
    // Extend XOR
    X[7] ^= X[1];    X[3] ^= X[2];    X[4] ^= X[0];
    
    T[0] = X[7];    T[1] = X[3];    T[2] = X[4];
    
    //S5_2
    X[6] ^= (T[0] & X[5]);
    
    T[0] ^= X[6];
    
    X[6] ^= (T[2] | T[1]);
    
    T[1] ^= X[5];
    
    X[5] ^= (X[6] | T[2]);
    
    T[2] ^= (T[1] & T[0]);
    
    // Truncate XOR and bit change
    X[2] ^= T[0];   T[0] = X[1] ^ T[2];    X[1] = X[0]^T[1];   X[0] = X[7];    X[7] = T[0];
    T[1] = X[3];    X[3] = X[6];    X[6] = T[1];
    T[2] = X[4];    X[4] = X[5];    X[5] = T[2];
    
    // Output: (MSb) x[7], x[6], x[5], x[4], x[3], x[2], x[1], x[0] (LSb)
    
  
}

void inv_sbox(u8 *X)
{    //(MSB: x[7], LSB: x[0])
    // Input: x[7], x[6], x[5], x[4], x[3], x[2], x[1], x[0]

    u8 T[3] = { 0, };

    T[0] = X[7]; X[7] = X[0]; X[0] = X[1]; X[1] = T[0];
    T[0] = X[7];    T[1] = X[6];    T[2] = X[5];
    // S52 inv
    X[4] ^= (X[3] | T[2]);
    X[3] ^= (T[2] | T[1]);
    T[1] ^= X[4];
    T[0] ^= X[3];
    T[2] ^= (T[1] & T[0]);
    X[3] ^= (X[4] & X[7]);
    //  Extended XOR
    X[0] ^= T[1]; X[1] ^= T[2]; X[2] ^= T[0];
    T[0] = X[3]; X[3] = X[6]; X[6] = T[0];
    T[0] = X[5]; X[5] = X[4]; X[4] = T[0];
    //  Truncated XOR
    X[7] ^= X[1];    X[3] ^= X[2];    X[4] ^= X[0];
    // Inv_S5_1
    X[4] ^= (X[5] & X[6]);
    X[5] ^= X[7];
    X[3] ^= (X[4] | X[5]);
    X[6] ^= X[3];
    X[7] ^= X[4];
    X[4] ^= (X[3] & X[5]);
    X[5] ^= (X[7] & X[6]);
    // Inv_S3
    X[2] = ~X[2];
    X[1] ^= X[2] | X[0];
    X[0] ^= X[2] | X[1];
    X[2] ^= X[1] & X[0];
    
    
     // Output: x[7], x[6], x[5], x[4], x[3], x[2], x[1], x[0]
}

//left rotation: (0,7,4,3,6,5,1,2)
void pbox(u8* X)
{
    X[1] = ((X[1] << 7)) | ((X[1] >> 1));
    X[2] = ((X[2] << 4)) | ((X[2] >> 4));
    X[3] = ((X[3] << 3)) | ((X[3] >> 5));
    X[4] = ((X[4] << 6)) | ((X[4] >> 2));
    X[5] = ((X[5] << 5)) | ((X[5] >> 3));
    X[6] = ((X[6] << 1)) | ((X[6] >> 7));
    X[7] = ((X[7] << 2)) | ((X[7] >> 6));

}

//left rotation(inverse): (0,1,4,5,2,3,7,6)
void inv_pbox(u8* X)
{
    X[1] = ((X[1] << 1)) | ((X[1] >> 7));
    X[2] = ((X[2] << 4)) | ((X[2] >> 4));
    X[3] = ((X[3] << 5)) | ((X[3] >> 3));
    X[4] = ((X[4] << 2)) | ((X[4] >> 6));
    X[5] = ((X[5] << 3)) | ((X[5] >> 5));
    X[6] = ((X[6] << 7)) | ((X[6] >> 1));
    X[7] = ((X[7] << 6)) | ((X[7] >> 2));
}

void ENC(u32* PLAIN_TEXT, u32* ROUND_KEY, u32* CIPHER_TEXT) {
    int i = 0;
    u8* P = (u8*)PLAIN_TEXT;
    u8* RK = (u8*)ROUND_KEY;
    keyadd(P, RK);
     
    for (i = 1; i < ROUND+1; i++)
    {
        sbox(P);
        pbox(P);
        
        keyadd(P, RK + (i * 8));
 
    }
}


void DEC(u32* CIPHER_TEXT, u32* ROUND_KEY, u32* PLAIN_TEXT) {
    int i = 0;
    u8* C = (u8*)CIPHER_TEXT;
    u8* RK = (u8*)ROUND_KEY;
    
    for (i = ROUND; i > 0; i--)
    {
        keyadd(C, RK + (i * 8));
        inv_pbox(C);
        inv_sbox(C);
#ifdef DEBUG
        printf("\nROUND %02i: %02X%02X%02X%02X, %02X%02X%02X%02X", i, C[7], C[6], C[5], C[4], C[3], C[2], C[1], C[0]);
#endif
    }
    keyadd(C, RK);
}

void ROUND_KEY_GEN() {
    u32 i, j;
    u32 RCON = 0;
    srand(time(NULL));
    
    
    //for (i = 0; i<SIZE; i++)
    //    PLAIN_TEXT[i] = rand() | (rand() << 16);
    
    //PIPO-64/128,PIPO-64/256 test vector
    //PLAIN_TEXT[0] = 0x1E270026;
    //PLAIN_TEXT[1] = 0x098552F6;
    
    //for (i = 0; i < MASTER_KEY_SIZE; i++)
    //    for (j = 0; j < INT_NUM; j++)
    //        MASTER_KEY[INT_NUM*i + j] = rand() | (rand() << 16);
    //PIPO-64/128 test vector
    //[97, 42, 202, 187, 236, 173, 31, 84] 0xbbca2a61, 0x541fadec
    //[49, 113, 184, 242, 31, 184, 56, 199] 0xf2b87131, 0xc738b81f
    
    //MASTER_KEY[0] = 0x2E152297;
    //MASTER_KEY[1] = 0x7E1D20AD;
    //MASTER_KEY[2] = 0x779428D2;
    //MASTER_KEY[3] = 0x6DC416DD;
    MASTER_KEY[0] = 0xbbca2a61;
    MASTER_KEY[1] = 0x541fadec;
    MASTER_KEY[2] = 0xf2b87130;
    MASTER_KEY[3] = 0xc738b81f;
    // //PIPO-64/256 test vector
    // MASTER_KEY[7] = 0x009A3AA4;
    // MASTER_KEY[6] = 0x76A96DB5;
    // MASTER_KEY[5] = 0x54A71206;
    // MASTER_KEY[4] = 0x26D15633;
    // MASTER_KEY[3] = 0x6DC416DD;
    // MASTER_KEY[2] = 0x779428D2;
    // MASTER_KEY[1] = 0x7E1D20AD;
    // MASTER_KEY[0] = 0x2E152297;

    
    for (i = 0; i < ROUND + 1; i++) {
        for (j = 0; j < INT_NUM; j++)
            ROUND_KEY[INT_NUM*i + j] = MASTER_KEY[(INT_NUM*i + j) % (MASTER_KEY_SIZE*INT_NUM)];
        ROUND_KEY[INT_NUM*i] ^= RCON;
        RCON++;

    }
}


uint8_t getRand(void) {
    return rand() % 256; //위험
}

void Mask_refreshing(uint8_t* x){
    uint8_t t=0;
    for(int j = 1; j < NUM_SHARES; j++) {
        t = getRand();
        x[j] ^=t;
        x[0] ^= t;
    }
}

void MaskArray(uint8_t y[][NUM_SHARES], uint8_t x[], uint8_t length) {
    uint8_t i,j;
    for(i = 0; i < length; i++) {
        y[i][0] = x[i];
        for(j = 1; j < NUM_SHARES; j++) {
            y[i][j] = getRand();
            y[i][0] ^= y[i][j];
        }
    }
}

void UnMaskArray(uint8_t y[], uint8_t x[][NUM_SHARES], uint8_t length) {
    uint8_t i,j;
    for(i = 0; i < length; i++) {
        y[i] = x[i][0];
        for(j = 1; j < NUM_SHARES; j++) {
            y[i] ^= x[i][j];
        }
    }
}
void ISW_AND(uint8_t* out, uint8_t* in1, uint8_t* in2){
    uint8_t temp[NUM_SHARES]={0,};
    uint8_t m1=0;
    uint8_t m2=0;

    for(int j = 1; j < NUM_SHARES; j++) {
        temp[j] = getRand();
        temp[0] = temp[0] ^ temp[j];
        m1 ^= in1[j];
        m2 ^= in2[j];
    }
    temp[0] = temp[0]^(in1[0]&in2[0]);
    temp[0] = temp[0]^(in1[0]&m2);
    temp[0] = temp[0]^(m1&in2[0]);
    temp[0] = temp[0]^(m1&m2);
    for(int j = 0; j < NUM_SHARES; j++)
    out[j]=temp[j];
}

void ISW_OR(uint8_t* out, uint8_t* in1, uint8_t* in2){
    uint8_t temp[NUM_SHARES]={0,};
    uint8_t m1=0;
    uint8_t m2=0;
    
    for(int j = 1; j < NUM_SHARES; j++) {
        temp[j] = getRand();
        temp[0] = temp[0] ^ temp[j];
        m1 ^= in1[j];
        m2 ^= in2[j];
    }
    temp[0] = temp[0]^(in1[0]&in2[0]);
    temp[0] = temp[0]^(in1[0]&m2);
    temp[0] = temp[0]^(m1&in2[0]);
    temp[0] = temp[0]^(m1&m2);
    for(int j = 0; j < NUM_SHARES; j++)
        out[j]=temp[j]^in1[j]^in2[j];
    
}

static uint8_t state[8][NUM_SHARES];
static uint8_t round_key[16][NUM_SHARES];

void m_sbox(u8 X[8][NUM_SHARES])
{
    u8 T[4][NUM_SHARES] = { 0, };
    
    //S5_1
    Mask_refreshing(X[7]);
    ISW_AND(T[3], X[7], X[6]);
    for(int i=0; i<NUM_SHARES;i++)
    X[5][i] ^= T[3][i];
    Mask_refreshing(X[3]);
    ISW_AND(T[3], X[3], X[5]);
    for(int i=0; i<NUM_SHARES;i++){
        X[4][i] ^= T[3][i];
        X[7][i] ^= X[4][i];
        X[6][i] ^= X[3][i];
    }
    Mask_refreshing(X[4]);
    ISW_OR(T[3], X[4], X[5]);
    for(int i=0; i<NUM_SHARES;i++){
        X[3][i] ^= T[3][i];
        X[5][i] ^= X[7][i];
    }
    Mask_refreshing(X[5]);
    ISW_AND(T[3], X[5], X[6]);
    for(int i=0; i<NUM_SHARES;i++)
    X[4][i] ^= T[3][i];
    
    //S3
    Mask_refreshing(X[1]);
    ISW_AND(T[3], X[1], X[0]);
    for(int i=0; i<NUM_SHARES;i++)
    X[2][i] ^= T[3][i];
    Mask_refreshing(X[2]);
    ISW_OR(T[3], X[2], X[1]);
    for(int i=0; i<NUM_SHARES;i++)
    X[0][i] ^= T[3][i];
    Mask_refreshing(X[2]);
    ISW_OR(T[3], X[2], X[0]);
    for(int i=0; i<NUM_SHARES;i++)
    X[1][i] ^= T[3][i];
    X[2][0] = ~X[2][0];
    
    // Extend XOR
    for(int i=0; i<NUM_SHARES;i++){
        X[7][i] ^= X[1][i];    X[3][i] ^= X[2][i];    X[4][i] ^= X[0][i];
    }
    
    for(int i=0; i<NUM_SHARES;i++){
    T[0][i] = X[7][i];    T[1][i] = X[3][i];    T[2][i] = X[4][i];
    }
    
    
    //S5_2
    Mask_refreshing(T[0]);
    ISW_AND(T[3], T[0], X[5]);
    for(int i=0; i<NUM_SHARES;i++){
    X[6][i] ^= T[3][i];
    T[0][i] ^= X[6][i];
    }
    Mask_refreshing(T[2]);
    ISW_OR(T[3], T[2], T[1]);
    for(int i=0; i<NUM_SHARES;i++){
    X[6][i] ^= T[3][i];
    T[1][i] ^= X[5][i];
    }
    Mask_refreshing(X[6]);
    ISW_OR(T[3], X[6], T[2]);
    for(int i=0; i<NUM_SHARES;i++)
    X[5][i] ^= T[3][i];
    Mask_refreshing(T[1]);
    ISW_AND(T[3], T[1], T[0]);
    for(int i=0; i<NUM_SHARES;i++)
    T[2][i] ^= T[3][i];
    
    
    
    for(int i=0; i<NUM_SHARES;i++){
        X[2][i] ^=T[0][i];
        T[0][i] = X[1][i] ^ T[2][i]; X[1][i] = X[0][i]^T[1][i];
        X[0][i] = X[7][i]; X[7][i] = T[0][i]; T[1][i] = X[3][i];
        X[3][i] = X[6][i]; X[6][i] = T[1][i]; T[2][i] = X[4][i];
        X[4][i] = X[5][i]; X[5][i] = T[2][i];
    
    }
   
}
void m_inv_sbox(u8 *X)
{    //(MSB: x[7], LSB: x[0])
    // Input: x[7], x[6], x[5], x[4], x[3], x[2], x[1], x[0]

    u8 T[3] = { 0, };

    T[0] = X[7]; X[7] = X[0]; X[0] = X[1]; X[1] = T[0];
    T[0] = X[7];    T[1] = X[6];    T[2] = X[5];
    // S52 inv
    X[4] ^= (X[3] | T[2]);
    X[3] ^= (T[2] | T[1]);
    T[1] ^= X[4];
    T[0] ^= X[3];
    T[2] ^= (T[1] & T[0]);
    X[3] ^= (X[4] & X[7]);
    //  Extended XOR
    X[0] ^= T[1]; X[1] ^= T[2]; X[2] ^= T[0];
    T[0] = X[3]; X[3] = X[6]; X[6] = T[0];
    T[0] = X[5]; X[5] = X[4]; X[4] = T[0];
    //  Truncated XOR
    X[7] ^= X[1];    X[3] ^= X[2];    X[4] ^= X[0];
    // Inv_S5_1
    X[4] ^= (X[5] & X[6]);
    X[5] ^= X[7];
    X[3] ^= (X[4] | X[5]);
    X[6] ^= X[3];
    X[7] ^= X[4];
    X[4] ^= (X[3] & X[5]);
    X[5] ^= (X[7] & X[6]);
    // Inv_S3
    X[2] = ~X[2];
    X[1] ^= X[2] | X[0];
    X[0] ^= X[2] | X[1];
    X[2] ^= X[1] & X[0];
     // Output: x[7], x[6], x[5], x[4], x[3], x[2], x[1], x[0]
}

//left rotation: (0,7,4,3,6,5,1,2)
void m_pbox(u8 X[8][NUM_SHARES])
{
    for(int i=0;i<NUM_SHARES;i++){
    X[1][i] = ((X[1][i] << 7)) | ((X[1][i] >> 1));
    X[2][i] = ((X[2][i] << 4)) | ((X[2][i] >> 4));
    X[3][i] = ((X[3][i] << 3)) | ((X[3][i] >> 5));
    X[4][i] = ((X[4][i] << 6)) | ((X[4][i] >> 2));
    X[5][i] = ((X[5][i] << 5)) | ((X[5][i] >> 3));
    X[6][i] = ((X[6][i] << 1)) | ((X[6][i] >> 7));
    X[7][i] = ((X[7][i] << 2)) | ((X[7][i] >> 6));
    }
}

//left rotation(inverse): (0,1,4,5,2,3,7,6)
void m_inv_pbox(u8 X[8][NUM_SHARES])
{
    for(int i=0;i<NUM_SHARES;i++){
        X[1][i] = ((X[1][i] << 1)) | ((X[1][i] >> 7));
        X[2][i] = ((X[2][i] << 4)) | ((X[2][i] >> 4));
        X[3][i] = ((X[3][i] << 5)) | ((X[3][i] >> 3));
        X[4][i] = ((X[4][i] << 2)) | ((X[4][i] >> 6));
        X[5][i] = ((X[5][i] << 3)) | ((X[5][i] >> 5));
        X[6][i] = ((X[6][i] << 7)) | ((X[6][i] >> 1));
        X[7][i] = ((X[7][i] << 6)) | ((X[7][i] >> 2));
    }

}

void m_keyadd(u8 val[8][NUM_SHARES], u8 rk[8][NUM_SHARES])
{
    for(int j = 0; j < NUM_SHARES; j++) {
                for(int k = 0; k < 8; k++) {
                    val[k][j] ^= rk[k][j];
                }
            }
}

void m_ENC(u32* PLAIN_TEXT, u32* ROUND_KEY, u32* CIPHER_TEXT) {
    
    int i = 0;
    u8* P = (u8*)PLAIN_TEXT;
    u8* RK = (u8*)ROUND_KEY;

    MaskArray(state, P, 8);
    MaskArray(round_key, RK, (ROUND + 1) * 8);

    m_keyadd(state, round_key);
    
    for (i = 1; i < ROUND+1; i++)
    {
        m_sbox(state);
        m_pbox(state);
        m_keyadd(state, round_key + (i * 8));
    }
    
    UnMaskArray(P,state,8);
}

#define secand(z,a,b,m1,m2,m3) z=(((m3^(a&b))^(a&m2))^(m1&b))^(m1&m2)
#define secor(z,a,b,m1,m2,m3) z=((((m3^(a&b))^(a&m2))^(m1&b))^(m1&m2))^a^b

void mask_v1_round_f(u8 X[8], u8 m[8])
{
   u8 t = 0;
   u8 t0 = 0;
   u8 t1 = 0;
   u8 tm0 = 0;
   u8 tm1 = 0;
   u8 _m = getRand();
   secand(t, X[7], X[6], m[7], m[6], _m);
   X[5] ^= t;
   m[5] ^= _m;  //_m^5
    
   secand(t, X[3], X[5], m[3], m[5], _m);
   X[4] ^= t;
   X[7] ^= X[4];
   X[6] ^= X[3];
   m[4] ^= _m;  //_m^4
   m[7] ^= m[4];//7^_m^4
   m[6] ^= m[3];//6^3
   
   secor(t, X[4], X[5], m[4], m[5], _m);
   X[3] ^= t;
   X[5] ^= X[7];
   m[3] ^= _m^m[4]^m[5];//3^_m
   m[5] ^= m[7];//5^_m^4^7
   
   
   secand(t, X[5], X[6], m[5], m[6], _m);
   X[4] ^= t;
   m[4] ^= _m;//4^_m^_m2
    
   secand(t, X[1], X[0], m[1], m[0], _m);
   X[2] ^= t;
   m[2] ^= _m;//2^_m
   secor(t, X[2], X[1], m[2], m[1], _m);
   X[0] ^= t;
   m[0] ^= _m^m[2]^m[1];//0^_m
   secor(t, X[2], X[0], m[2], m[0], _m);
   X[1] ^= t;
   m[1] ^= _m^m[2]^m[0]; //1^_m
   X[2] = ~X[2];
   
   X[7] ^= X[1];
   X[3] ^= X[2];
   X[4] ^= X[0];
   m[7] ^= m[1];//7^_m^4^1^_m
   m[3] ^= m[2];//3^_m^ 2^_m
   m[4] ^= m[0];//4^_m^_m2^0^_m
    
   t0 = X[7];
   t1 = X[3];
   
   secand(t, t0, X[5], m[7], m[5], _m);
   X[6] ^= t;
   m[6] ^= _m;
   t0 ^= X[6];//m[6]^m[7]

    tm0 = m[6]^m[7];
   secor(t, X[4], t1, m[4], m[3], _m);
   X[6] ^= t;
   t1 ^= X[5];
    tm1 = m[5]^m[3];
   m[6] ^= _m^m[4]^m[3];

    
   secor(t, X[6], X[4], m[6], m[4], _m);
   X[5] ^= t;
   m[5] ^= _m^m[6]^m[4];
   
   secand(t, t1, t0, tm1, tm0, _m);
   t ^= X[4];
    
   X[2] ^=t0;
   m[2] ^= tm0;
   t0 = X[1] ^t;
    tm0 = m[1] ^ m[4]^_m;
   X[1] = X[0] ^ t1;
   m[1] = m[0] ^ tm1;
    
   X[0] = X[7];
   m[0] = m[7];
    
   X[7] = t0;
   m[7] = tm0;
    
   t1 = X[3];
   X[3] = X[6];
    
   X[6] = t1;
   t1 = m[3];
   m[3] = m[6];
   m[6] = t1;
   
   t1 = X[4];
   X[4] = X[5];
   X[5] = t1;
   t1 = m[4];
   m[4] = m[5];
   m[5] = t1;
   
   X[1] = ((X[1] << 7)) | ((X[1] >> 1));
   X[2] = ((X[2] << 4)) | ((X[2] >> 4));
   X[3] = ((X[3] << 3)) | ((X[3] >> 5));
   X[4] = ((X[4] << 6)) | ((X[4] >> 2));
   X[5] = ((X[5] << 5)) | ((X[5] >> 3));
   X[6] = ((X[6] << 1)) | ((X[6] >> 7));
   X[7] = ((X[7] << 2)) | ((X[7] >> 6));

   m[1] = ((m[1] << 7)) | ((m[1] >> 1));
   m[2] = ((m[2] << 4)) | ((m[2] >> 4));
   m[3] = ((m[3] << 3)) | ((m[3] >> 5));
   m[4] = ((m[4] << 6)) | ((m[4] >> 2));
   m[5] = ((m[5] << 5)) | ((m[5] >> 3));
   m[6] = ((m[6] << 1)) | ((m[6] >> 7));
   m[7] = ((m[7] << 2)) | ((m[7] >> 6));


}



void mask_v1_enc(u32* PLAIN_TEXT, u32* ROUND_KEY, u32* CIPHER_TEXT){
    int i = 0;
    u8* P = (u8*)PLAIN_TEXT;
    u8* RK = (u8*)ROUND_KEY;
    u8 m[8] = {0,};
    u8 m2[8] = {0,};
    
    m[0]=rand();
    m[1]=rand();
    m[2]=rand();
    m[3]=rand();
    m[4]=rand();
    m[5]=rand();
    m[6]=rand();
    m[7]=rand();
    
    m2[0]=rand();
    m2[1]=rand();
    m2[2]=rand();
    m2[3]=rand();
    m2[4]=rand();
    m2[5]=rand();
    m2[6]=rand();
    m2[7]=rand();
    
    for (int i=0;i<(ROUND + 1) * 8;i++){
        RK[i]^=m2[i%8];
    }
    
    P[0]^=m[0];
    P[1]^=m[1];
    P[2]^=m[2];
    P[3]^=m[3];
    P[4]^=m[4];
    P[5]^=m[5];
    P[6]^=m[6];
    P[7]^=m[7];
    
    P[0]^=RK[0];
    P[1]^=RK[1];
    P[2]^=RK[2];
    P[3]^=RK[3];
    P[4]^=RK[4];
    P[5]^=RK[5];
    P[6]^=RK[6];
    P[7]^=RK[7];
    m[0]^=m2[0];
    m[1]^=m2[1];
    m[2]^=m2[2];
    m[3]^=m2[3];
    m[4]^=m2[4];
    m[5]^=m2[5];
    m[6]^=m2[6];
    m[7]^=m2[7];
    
    for (i = 1; i < ROUND+1; i++)
    {
        mask_v1_round_f(P,m);
        
        P[0]^=RK[0+(i * 8)];
        P[1]^=RK[1+(i * 8)];
        P[2]^=RK[2+(i * 8)];
        P[3]^=RK[3+(i * 8)];
        P[4]^=RK[4+(i * 8)];
        P[5]^=RK[5+(i * 8)];
        P[6]^=RK[6+(i * 8)];
        P[7]^=RK[7+(i * 8)];
        m[0]^=m2[0];
        m[1]^=m2[1];
        m[2]^=m2[2];
        m[3]^=m2[3];
        m[4]^=m2[4];
        m[5]^=m2[5];
        m[6]^=m2[6];
        m[7]^=m2[7];

    }
    
    P[0]^=m[0];
    P[1]^=m[1];
    P[2]^=m[2];
    P[3]^=m[3];
    P[4]^=m[4];
    P[5]^=m[5];
    P[6]^=m[6];
    P[7]^=m[7];
}


#define secor2(z,a0,b0,a1,b1,c) z= ((a0&b0)^(a0|b1))^((a1|b0)^(c^b1))

void mask_v2_round_f(u8 X[8], u8 m0, u8 m1, u8 m2){
    u8 T[3] = { 0, };
    u8 temp=0;
    u8 c = m0 | m1;
    //(MSB: x[7], LSB: x[0])
    // Input: x[7], x[6], x[5], x[4], x[3], x[2], x[1], x[0]
    
    //S5_1
    secand(temp, X[7], X[6], m0, m1, m2);
    X[5] ^= temp;//(m1^m2)=m0
    
    secand(temp,X[3],X[5], m2, m0, m1);
    X[4] ^= temp; //m0^m1= m2
    
    X[7] ^= X[4]; //m0^m2 = m1
    
    X[6] ^= X[3]; //m1^m2=m0
    
    secor2(temp,X[5],X[4],m0,m2,c);
    X[3] ^= temp; //m2 ^ m0 = m1
    
    X[5] ^= X[7]; //m0^m1 = m2
    
    secand(temp,X[5],X[6], m2,m0,m1);
    X[4] ^=temp; // m2^m1=m0
    
    //S3
    secand(temp,X[1],X[0], m1,m0,m2);
    X[2]^=temp; // m1 ^ m2 = m0
    
    secor2(temp,X[1],X[2],m1,m0,c);
    X[0] ^=temp; //m0 ^ m1 = m2
    
    secor2(temp,X[2],X[0],m0,m2,c);
    X[1] ^=temp; //m1^m0 =m2
    
    X[2] = ~X[2]; //m0
    
    // Extend XOR
    X[7] ^= X[1]; //(m1^m2)=m0
    
    X[3] ^= X[2]; //m1^m0 = m2
    
    X[4] ^= X[0]; //m0^m2=m1
    
    T[0] = X[7]; // m0
    T[1] = X[3]; //m2
    T[2] = X[4]; //m1
    
    //S5_2
    secand(temp,X[5], T[0], m2,m0,m1);
    X[6] ^=temp; // m0^m1 =m2
    
    T[0] ^= X[6]; // m0^m2 = m1
    
    secor2(temp,T[2],T[1], m1,m2,c);
    X[6] ^= temp; // m2^m1=m0
    
    T[1] ^= X[5]^m0; // m2^m1=m0
    
    secor2(temp,X[6],T[2], m0,m1,c);
    X[5] ^=temp; //m2 ^ m0=m1
    
    secand(temp,T[1], T[0], m0,m1,m2);
    T[2]^=temp; //   m1 ^ m2=m0
    
    // Truncate XOR and bit change
    X[2] ^= T[0]; // m0^m1=m2
    T[0] = X[1] ^ T[2];   // m2^ m0 = m1
    X[1] = X[0] ^ T[1];   // m2^m0=m1
    X[0] = X[7]^m1;   //  m2
    X[7] = T[0]; //  m1
    T[1] = X[3]; // m2
    X[3] = X[6]; //  m0
    X[6] = T[1]; //m2
    T[2] = X[4]; //m1
    X[4] = X[5]; //m1
    X[5] = T[2]; //m1
    
    
    // Output: (MSb) x[7], x[6], x[5], x[4], x[3], x[2], x[1], x[0] (LSb)
    X[1] = ((X[1] << 7)) | ((X[1] >> 1));
    X[2] = ((X[2] << 4)) | ((X[2] >> 4));
    X[3] = ((X[3] << 3)) | ((X[3] >> 5));
    X[4] = ((X[4] << 6)) | ((X[4] >> 2));
    X[5] = ((X[5] << 5)) | ((X[5] >> 3));
    X[6] = ((X[6] << 1)) | ((X[6] >> 7));
    X[7] = ((X[7] << 2)) | ((X[7] >> 6));
}
void mask_v2_enc(u32* PLAIN_TEXT, u32* ROUND_KEY, u32* CIPHER_TEXT) {
   int i = 0;
   u8* P = (u8*)PLAIN_TEXT;
   u8* RK = (u8*)ROUND_KEY;
   u8 m0=0;
   u8 m1=0;
   u8 m2=0;
   u8 m[8] = {0,};
   m0 = getRand();
   m1 = getRand();
   m2 = m0^m1;
   m[0] = m1;
   m[1] = ((m1 << 7) | (m1 >> 1))^m1;
   m[2] = ((m2 << 4) | (m2 >> 4))^m1;
   m[3] = ((m0 << 3) | (m0 >> 5))^m2;
   m[4] = ((m1 << 6) | (m1 >> 2))^m0;
   m[5] = ((m1 << 5) | (m1 >> 3))^m1;
   m[6] = ((m2 << 1) | (m2 >> 7))^m1;
   m[7] = ((m1 << 2) | (m1 >> 6))^m0;
   

   RK[0] ^= m2;
   RK[1] ^= m2;
   RK[2] ^= m2;
   RK[3] ^= m1;
   RK[4] ^= m2;
   RK[5] ^= m2;
   RK[6] ^= m2;
   RK[7] ^= m2;
   
   for (i = 8; i < (ROUND + 1) * 8; i++) {
      RK[i] ^= m[i % 8];
   }
   
   
   P[0] ^= m1;
   P[1] ^= m0;
   P[2] ^= m0;
   P[3] ^= m0;
   P[4] ^= m1;
   P[5] ^= m0;
   P[6] ^= m0;
   P[7] ^= m1;
    
   P[0] ^= RK[0];
   P[1] ^= RK[1];
   P[2] ^= RK[2];
   P[3] ^= RK[3];
   P[4] ^= RK[4];
   P[5] ^= RK[5];
   P[6] ^= RK[6];
   P[7] ^= RK[7];
   
   
   for (i = 1; i < ROUND + 1; i++)
   {
      mask_v2_round_f(P, m0, m1, m2);
      P[0] ^= RK[0 + (i * 8)];
      P[1] ^= RK[1 + (i * 8)];
      P[2] ^= RK[2 + (i * 8)];
      P[3] ^= RK[3 + (i * 8)];
      P[4] ^= RK[4 + (i * 8)];
      P[5] ^= RK[5 + (i * 8)];
      P[6] ^= RK[6 + (i * 8)];
      P[7] ^= RK[7 + (i * 8)];
   }
   P[0] ^= m0;
   P[1] ^= m1;
   P[2] ^= m1;
   P[3] ^= m2;
   P[4] ^= m0;
   P[5] ^= m1;
   P[6] ^= m1;
   P[7] ^= m0;
   
}

int main(void) {

    ROUND_KEY_GEN();
    
    PLAIN_TEXT[0] = 0xcc1d92ab;
    PLAIN_TEXT[1] = 0xf2a3f529;
    
    ENC(PLAIN_TEXT, ROUND_KEY, CIPHER_TEXT);
    printf("\n%x %x\n",PLAIN_TEXT[0],PLAIN_TEXT[1]);
    PLAIN_TEXT[0] = 0xcc1d92ab;
    PLAIN_TEXT[1] = 0xf2a3f529;
    
    m_ENC(PLAIN_TEXT, ROUND_KEY, CIPHER_TEXT);
    printf("\n%x %x\n",PLAIN_TEXT[0],PLAIN_TEXT[1]);
    
    PLAIN_TEXT[0] = 0xcc1d92ab;
    PLAIN_TEXT[1] = 0xf2a3f529;
    
    //제안 구현 v1
    mask_v1_enc(PLAIN_TEXT, ROUND_KEY, CIPHER_TEXT3);
    printf("\n%x %x\n",PLAIN_TEXT[0],PLAIN_TEXT[1]);
    ROUND_KEY_GEN();
    PLAIN_TEXT[0] = 0xcc1d92ab;
    PLAIN_TEXT[1] = 0xf2a3f529;
    //제안 구현 v2
    mask_v2_enc(PLAIN_TEXT, ROUND_KEY, CIPHER_TEXT3);
    printf("\n%x %x\n",PLAIN_TEXT[0],PLAIN_TEXT[1]);
    
    return EXIT_SUCCESS;
}
/*
int main(void) {

    ROUND_KEY_GEN();

    ENC(PLAIN_TEXT, ROUND_KEY, CIPHER_TEXT);
    m_ENC(PLAIN_TEXT, ROUND_KEY, CIPHER_TEXT2);
    printf("\n\n==CIPHER_TEXT==\n");
    printf("%08X, %08X\n", PLAIN_TEXT[1], PLAIN_TEXT[0]);
    
    DEC(PLAIN_TEXT, ROUND_KEY, CIPHER_TEXT);
    
    printf("\n==PLAIN_TEXT==\n");
    printf("%08X, %08X\n", PLAIN_TEXT[1], PLAIN_TEXT[0]);

    return EXIT_SUCCESS;
}

*/
