import struct
import numpy as np
from typing import Tuple, Optional


from tensorflow.python.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout, Conv1D, MaxPooling1D
import numpy as np
import random

from tensorflow.keras import datasets, layers, models

######################################put_handeler#################

def __poi_converter(poi: Tuple[int, int], _samples) -> Tuple[Tuple[int, int], int]:
    """POI의 범위를 검사하고 반환해주는 함수

    :param poi: (시작, 끝)으로 이루어진 poi 범위
    :param _samples: 파형의 실제 샘플수
    :return: (poi, poi_len)
    """
    if poi is None: _trunc_range = (0, _samples - 1)  # 0 ~ 25002-1
    else: _trunc_range = (poi[0], poi[1])  # 1 ~ 25002

    _trunc_len = _trunc_range[1] - _trunc_range[0] + 1

    if _trunc_range[0] < 0 or _trunc_range[1] > _samples - 1 or _trunc_len <= 0:
        raise RuntimeError("\nPOI error. All: poi=None, else: (a, b). a>=0, b<=SAMPLES")

    return _trunc_range, _trunc_len
    pass

def convert_btr_2_npy(poi: Optional[Tuple[int, int]], import_file_path: str, traces_path_exp: Optional[str] = None) -> np.ndarray:
    """Binary traces(.btr) 파일을 numpy.ndarray 의 직렬화된 파일로 저장하는 함수

    :param poi: 일부만 추출할 경우 인자 전달. 전체 파형을 추출할 경우 None 전달
    :param import_file_path: .btr 파일의 위치 (경로 + 파일명)
    :param traces_path_exp:  변환된 numpy.ndarray 객체 파일이 저장될 위치 (경로 + 파일명). 확장자는 .npy로 한다.
    :return: numpy array로 변환된 파형 데이터
    """
    print('Binary Traces file. (.btr)')
    print('-' * 50)
    _fp = open(import_file_path, 'rb')

    _trace_num = struct.unpack('i', _fp.read(4))[0]  # num of traces
    _trace_sample = struct.unpack('i', _fp.read(4))[0]  # samples

    _trunc_range, _trunc_len = __poi_converter(poi, _trace_sample)

    _traces = np.empty(shape=(_trace_num, _trunc_len))

    for _i in range(_trace_num):
        __trace_index = struct.unpack('i', _fp.read(4))[0]
        _traces[_i] = struct.unpack(str(_trace_sample) + 'f', _fp.read(_trace_sample * 4))[_trunc_range[0]: _trunc_range[1] + 1]
        print(f'\r* Trace-{__trace_index + 1}', ' read', end='', flush=True)

    _fp.close()
    print()
    print('-' * 50)

    if traces_path_exp is not None:
        np.save(traces_path_exp, _traces)
        print(f'Traces - {traces_path_exp} saved.')

    return _traces
    pass

def convert_hex_data_2_npy(import_file_path: str, export_file_path: Optional[str] = None) -> np.ndarray:
    """16진수 문자열로 구성된 평문/암호문 파일을 읽어 numpy.ndarray 의 직렬화된 파일로 저장하는 함수

    :param import_file_path: 평문/암호문의 16진수 문자열이 나열된 텍스트 파일 위치 (경로 + 파일명)
    :param export_file_path: numpy.ndarray로 변환되어 저장될 파일의 위치 (경로 + 파일명). 확장자는 .npy로 한다.
    :return: numpy array로 변환된 데이터
    """
    _fp = open(import_file_path, 'r')
    _data = _fp.readlines()
    for i in range(len(_data)):
        _data[i] = _data[i].replace(" ", "").replace("\n", "")

    _data = np.array(_data)

    if export_file_path is not None:
        np.save(export_file_path, _data)

    return _data
    pass


#AES_S_BOX = (
#    0x63, 0x7C, 0x77, 0x7B, 0xF2, 0x6B, 0x6F, 0xC5, 0x30, 0x01, 0x67, 0x2B, 0xFE, 0xD7, 0xAB, 0x76,
#    0xCA, 0x82, 0xC9, 0x7D, 0xFA, 0x59, 0x47, 0xF0, 0xAD, 0xD4, 0xA2, 0xAF, 0x9C, 0xA4, 0x72, 0xC0,
#    0xB7, 0xFD, 0x93, 0x26, 0x36, 0x3F, 0xF7, 0xCC, 0x34, 0xA5, 0xE5, 0xF1, 0x71, 0xD8, 0x31, 0x15,
#    0x04, 0xC7, 0x23, 0xC3, 0x18, 0x96, 0x05, 0x9A, 0x07, 0x12, 0x80, 0xE2, 0xEB, 0x27, 0xB2, 0x75,
#    0x09, 0x83, 0x2C, 0x1A, 0x1B, 0x6E, 0x5A, 0xA0, 0x52, 0x3B, 0xD6, 0xB3, 0x29, 0xE3, 0x2F, 0x84,
#    0x53, 0xD1, 0x00, 0xED, 0x20, 0xFC, 0xB1, 0x5B, 0x6A, 0xCB, 0xBE, 0x39, 0x4A, 0x4C, 0x58, 0xCF,
#    0xD0, 0xEF, 0xAA, 0xFB, 0x43, 0x4D, 0x33, 0x85, 0x45, 0xF9, 0x02, 0x7F, 0x50, 0x3C, 0x9F, 0xA8,
#    0x51, 0xA3, 0x40, 0x8F, 0x92, 0x9D, 0x38, 0xF5, 0xBC, 0xB6, 0xDA, 0x21, 0x10, 0xFF, 0xF3, 0xD2,
#    0xCD, 0x0C, 0x13, 0xEC, 0x5F, 0x97, 0x44, 0x17, 0xC4, 0xA7, 0x7E, 0x3D, 0x64, 0x5D, 0x19, 0x73,
#    0x60, 0x81, 0x4F, 0xDC, 0x22, 0x2A, 0x90, 0x88, 0x46, 0xEE, 0xB8, 0x14, 0xDE, 0x5E, 0x0B, 0xDB,
#    0xE0, 0x32, 0x3A, 0x0A, 0x49, 0x06, 0x24, 0x5C, 0xC2, 0xD3, 0xAC, 0x62, 0x91, 0x95, 0xE4, 0x79,
#    0xE7, 0xC8, 0x37, 0x6D, 0x8D, 0xD5, 0x4E, 0xA9, 0x6C, 0x56, 0xF4, 0xEA, 0x65, 0x7A, 0xAE, 0x08,
#    0xBA, 0x78, 0x25, 0x2E, 0x1C, 0xA6, 0xB4, 0xC6, 0xE8, 0xDD, 0x74, 0x1F, 0x4B, 0xBD, 0x8B, 0x8A,
#    0x70, 0x3E, 0xB5, 0x66, 0x48, 0x03, 0xF6, 0x0E, 0x61, 0x35, 0x57, 0xB9, 0x86, 0xC1, 0x1D, 0x9E,
#    0xE1, 0xF8, 0x98, 0x11, 0x69, 0xD9, 0x8E, 0x94, 0x9B, 0x1E, 0x87, 0xE9, 0xCE, 0x55, 0x28, 0xDF,
#    0x8C, 0xA1, 0x89, 0x0D, 0xBF, 0xE6, 0x42, 0x68, 0x41, 0x99, 0x2D, 0x0F, 0xB0, 0x54, 0xBB, 0x16,
#)


#def parse_from_hex(input_hex: str, target_byte: int) -> int:
#    """16진수 문자열에서 원하는 부분의 바이트를 추출하는 함수  (ex> parse_from_hex('1234', 2) -> 52(0x34))

#    :param input_hex: 원하는 바이트를 추출할 대상의 16진수 문자열(길이는 짝수여야함)
#    :param target_byte: 원하는 대상의 바이트 순서 (1 ~ ?)
#    :return: 원하는 부분의 바이트를 10진수로 변환한 값
#    """
#    _len_input = len(input_hex)
#    if _len_input/2 < target_byte:
#        print("arg Target_byte < ", _len_input/2, sep='')
#        return 0
#    for i, hex_index in enumerate(range(0, _len_input, 2)):
#        if i == target_byte - 1:
#            return int(input_hex[hex_index: hex_index+2], 16)
#    pass


#def aes_subbytes_attack(plain: str, cipher: str, g_key: int, target_byte) -> int:
#    """AES의 1라운드 SubBytes 를 공격하는 함수

#    :param plain: 평문
#    :param cipher: 암호문
#    :param g_key: 키
#    :param target_byte: 찾고자 하는 키의 바이트 순서
#    :return: 계산된 중간값(1바이트)
#    """
#    return AES_S_BOX[parse_from_hex(plain, target_byte) ^ g_key]
#    pass


#AVR-AES 라벨링 #(16201~ 16300)

#traces = convert_btr_2_npy((16201, 16300), "/Users/kb/Desktop/1212/ML-STM-AES.btr", None)
#plain = convert_hex_data_2_npy("/Users/kb/Desktop/1212/ML-STM-AES-plain.txt", None)
#keys = convert_hex_data_2_npy("/Users/kb/Desktop/1212/ML-STM-AES-key.txt", None)

#target_byte = 1
#label = []
#for p, key in zip(plain, keys):
#    _key = parse_from_hex(key, target_byte)
#    label.append(aes_subbytes_attack(p[0:32], "", _key, target_byte))

#np.save("/Users/kb/Desktop//ml-avr-aes-label.npy", traces)
#np.save("/Users/kb/Desktop//ml-avr-aes-label.npy", label)


traces = np.load("ml-avr-aes-traces.npy")
label = np.load("ml-avr-aes-label.npy")

traces = (traces-np.min(traces))/(np.max(traces)-np.min(traces))

traces_train = traces[0:4500]
traces_test = traces[4500:5000]


label_train = label[0:4500]
label_test = label[4500:5000]

#model = models.Sequential()
#model.add(layers.Conv1D(filters=32, kernel_size=3,  activation='relu', input_shape=(100,1)))
#model.add(layers.AveragePooling1D((2)))
#model.add(layers.Conv1D(filters=32, kernel_size=3,  activation='relu'))
#model.add(layers.AveragePooling1D((2)))
#model.add(Flatten())
#model.add(Dense(64, activation='relu'))
#model.add(Dense(256, activation='softmax'))

#model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])

#model.fit(traces_train, label_train, epochs=1500)

#test_loss, test_acc = model.evaluate(traces_test,  label_test, verbose=2)

#model.save('my_model2.h5')

from tensorflow.keras.models import load_model
new_model = load_model('my_model.h5')
new_model.summary()

new_model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])

test_loss, test_acc = new_model.evaluate(traces_test,  label_test, verbose=2)

print("Test accuracy: ", test_acc)

# test random trace of traces_test
predictions = new_model.predict(traces_test)
for i in range(500) :
    if(np.argmax(predictions[i])== label_test[i]) :
        print(i,"st")
        print([round(p, 4) for p in predictions[i]])
        print("predict : ",np.argmax(predictions[i]))
        print("answer : ", label_test[i])




